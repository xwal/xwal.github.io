//
//  MainNewsModel.h
//  ZLjiemianDemo
//
//  Created by 千锋 on 15/12/17.
//  Copyright (c) 2015年 千锋. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FirstPageBaseModel.h"
@class Author_List;
@interface MainNewsModel : FirstPageBaseModel

@property (nonatomic, copy) NSString *ID;

@property (nonatomic, copy) NSString *hit;

@property (nonatomic, copy) NSString *z_image;

@property (nonatomic, copy) NSString *c_image;

@property (nonatomic, copy) NSString *headline;

@property (nonatomic, copy) NSString *published;

@property (nonatomic, strong) NSArray *author_list;

@property (nonatomic, copy) NSString *tags;

@property (nonatomic, copy) NSString *comment;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *cl_image;

@property (nonatomic, copy) NSString *summary;

@property (nonatomic, copy) NSString *s_image;

@property (nonatomic, copy) NSString *img;

@property (nonatomic, copy) NSString *o_image;

@property (nonatomic, copy) NSString *image_path;

@property (nonatomic, copy) NSString *publishtime;

@property (nonatomic, copy) NSString *status;

@property (nonatomic, copy) NSString *i_show_tpl;

@end

@interface Author_List : NSObject

@property (nonatomic, copy) NSString *remark;

@property (nonatomic, copy) NSString *uid;

@property (nonatomic, copy) NSString *weixin;

@property (nonatomic, copy) NSString *is_v;

@property (nonatomic, copy) NSString *is_show_v;

@property (nonatomic, copy) NSString *user_other;

@property (nonatomic, copy) NSString *head_img;

@property (nonatomic, copy) NSString *name;

@property (nonatomic, copy) NSString *url;

@end

