//
//  FirstScrollModel.m
//  ZLjiemianDemo
//
//  Created by 千锋 on 15/12/13.
//  Copyright (c) 2015年 千锋. All rights reserved.
//

#import "FirstScrollModel.h"

@implementation FirstScrollModel
{
    NSInteger _currentPage;//当前页数

}




//分类滚动条请求数据
+(NSArray *)requestForButtonTitleWithUrl:(NSURL*)url{
    
    
    //通过NSData同步请求数据
    NSData * data =[NSData dataWithContentsOfURL:url];
 
    //将data转化为JSON对象
    NSDictionary * dataDict =[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
    NSArray *  resultArray = dataDict[@"result"];
    NSMutableArray * nameArray = [[NSMutableArray alloc]init];
    //遍历数组
    for (NSDictionary * dict in resultArray) {
        NSString * buttonTitle = dict[@"name"];
        [nameArray addObject:buttonTitle];
      
    }
    //暂时只获取标题名称
    return [nameArray copy];
}



//解析首页数据
-(void)ruquestFirstPageWithPage:(NSInteger)page{
    //拼接Url
    NSString * url = [NSString stringWithFormat:FISRT_PAGE_API,page];

}










@end
