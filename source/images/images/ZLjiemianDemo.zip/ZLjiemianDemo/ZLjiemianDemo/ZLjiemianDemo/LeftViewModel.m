//
//  LeftViewModel.m
//  ZLjiemianDemo
//
//  Created by 千锋 on 15/12/20.
//  Copyright (c) 2015年 千锋. All rights reserved.
//

#import "LeftViewModel.h"

@implementation LeftViewModel

-(void)setValue:(id)value forUndefinedKey:(NSString *)key{

    if ([key isEqualToString:@"id"]) {
        self.ID = value;
    }
    

}

-(instancetype)valueForUndefinedKey:(NSString *)key{


 
    return nil;
}


@end


