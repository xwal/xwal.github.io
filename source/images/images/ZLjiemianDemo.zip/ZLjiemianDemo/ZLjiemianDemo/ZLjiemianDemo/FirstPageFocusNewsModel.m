//
//  FirstPageFocusNewsModel.m
//  ZLjiemianDemo
//
//  Created by 千锋 on 15/12/16.
//  Copyright (c) 2015年 千锋. All rights reserved.
//

#import "FirstPageFocusNewsModel.h"

@implementation FirstPageFocusNewsModel

//解决关键字冲突
-(void)setValue:(id)value forUndefinedKey:(NSString *)key{
    if ([key isEqualToString:@"id"]) {
        self.ID =value;
    }

}


@end
