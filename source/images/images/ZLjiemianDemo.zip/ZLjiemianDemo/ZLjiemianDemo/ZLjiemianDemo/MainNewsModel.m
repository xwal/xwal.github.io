//
//  MainNewsModel.m
//  ZLjiemianDemo
//
//  Created by 千锋 on 15/12/17.
//  Copyright (c) 2015年 千锋. All rights reserved.
//

#import "MainNewsModel.h"

@implementation MainNewsModel

//解决关键字冲突
-(void)setValue:(id)value forUndefinedKey:(NSString *)key{
    if ([key isEqualToString:@"id"]) {
        self.ID =value;
    }
    
}



+ (NSDictionary *)objectClassInArray{
    return @{@"author_list" : [Author_List class]};
}

@end


@implementation Author_List

@end


