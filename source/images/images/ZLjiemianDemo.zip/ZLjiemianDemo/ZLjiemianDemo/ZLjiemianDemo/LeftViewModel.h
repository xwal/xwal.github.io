//
//  LeftViewModel.h
//  ZLjiemianDemo
//
//  Created by 千锋 on 15/12/20.
//  Copyright (c) 2015年 千锋. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FirstPageBaseModel.h"
@interface LeftViewModel : FirstPageBaseModel


@property (nonatomic, copy) NSString *slogan;

@property (nonatomic, copy) NSString *sort;

@property (nonatomic, copy) NSString *unistr;

@property (nonatomic, copy) NSString *ID;

@property (nonatomic, copy) NSString *show;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *type;

@property (nonatomic, copy) NSString *icon;

@property (nonatomic, copy) NSString *url;


@end

