//
//  ViewController.m
//  ZLjiemianDemo
//
//  Created by 千锋 on 15/12/13.
//  Copyright (c) 2015年 千锋. All rights reserved.
//

#define SCROLLVIEW_HEIGHT 30
#define TITLE_BUTTON_WIDTH 100
#define FIRST_BUTTON_TAG 100
#define FIRST_CELL_HEIGHT 250
#define MAIN_NEWS_CELL_HEIGHT 250
#import "ViewController.h"
#import "PrefixHeader.pch"
#import "FirstScrollModel.h"
#import "FocusCell.h"
#import "MainNewsModel.h"
#import "MainNewsCell.h"
#import "TableFooterView.h"
#import "LimitFreeNetworkingManager.h"
#import "LeftTableViewController.h"
#import "NewsDetailViewController.h"

@interface ViewController ()<UITableViewDelegate,UITableViewDataSource>
{
    UIScrollView * _scrollView;//滚动视图
    UILabel * _label;
    UILabel * _preLabel;//记录label;
    UITableView * _tableView;//表格视图
    UIButton * _preButton;//记录按钮
    NSInteger  _currentPage;//记录当前首页请求页数
    UIRefreshControl * _refreshControl;//刷新控件
    TableFooterView * _tableFooterView;//表头
    
}

@property(nonatomic,copy)NSMutableArray * dataArray;//数据源
@property(nonatomic,strong)LimitFreeNetworkingManager * manager;//网络请求
- (IBAction)LeftButtonClicked:(UIBarButtonItem *)sender;
- (IBAction)RightButtonClicked:(UIBarButtonItem *)sender;

@end

@implementation ViewController
// 通过懒加载方式创建对象，重写属性的Getter方法
// 如果重写了Getter方法，只能通过属性访问，不能通过实例变量访
-(LimitFreeNetworkingManager*)manager{
    if (!_manager) {
        _manager =[LimitFreeNetworkingManager manager];
    }

 
    return _manager;
}




//懒加载
-(NSMutableArray *)dataArray{
    if (!_dataArray) {
        _dataArray = [[NSMutableArray alloc]init];
    }


    return _dataArray;

}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [self createUI];
    

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


//创建UI
-(void)createUI{
    //关闭导航条半透明，
    self.navigationController.navigationBar.translucent = NO;
    //创建ScrollView
    [self  createScrollView];
     [self createTableView];
    

}

//创建ScrollView及Button
-(void)createScrollView{
    //创建ScrollView
    _scrollView =[[UIScrollView alloc]initWithFrame:CGRectMake(0,0,375,SCROLLVIEW_HEIGHT)];
    //设置背景颜色
    _scrollView.showsHorizontalScrollIndicator =NO;

    [self.view addSubview:_scrollView];
    //循环创建button
    NSURL * firstScrollViewUrl =[NSURL URLWithString:SCROLLVIEW_API];
//    //有网启动
//    NSArray * titleNameArray =[self requestForButtonTitleWithUrl:firstScrollViewUrl];
    //无网测试
    NSArray * titleNameArray =@[@"首页",@"中国",@"娱乐",@"体育"];
    for (int index=0; index<titleNameArray.count; index++) {
        UIButton * button =[UIButton buttonWithType:UIButtonTypeSystem];
        NSLog(@"+++++++");
        //将Button添加到ScrollView中
        [_scrollView addSubview:button];
        button.frame = CGRectMake(index*TITLE_BUTTON_WIDTH,0, TITLE_BUTTON_WIDTH, SCROLLVIEW_HEIGHT);
        [button setTitle:titleNameArray[index] forState:UIControlStateNormal];
        //设置选中状态文字颜色
        button.backgroundColor = [UIColor grayColor];
        
        //设置标记值
        button.tag =FIRST_BUTTON_TAG+index;
        //100 101 102 103 ...
       //添加事件响应
        [button addTarget:self action:@selector(buttonClicked:) forControlEvents:UIControlEventTouchUpInside];
        
    }
    _scrollView.contentSize =CGSizeMake(titleNameArray.count*TITLE_BUTTON_WIDTH,SCROLLVIEW_HEIGHT);
    
    //创建红色移动条
    _label =[[UILabel alloc]init];
    _label.backgroundColor =[UIColor redColor];
    
    
}
//实现事件响应方法
-(void)buttonClicked:(UIButton *) sender{
    //找到对应的button
    UIButton * button  =(UIButton*)[self.view viewWithTag:sender.tag];
    //找到上一个button
    _preButton.backgroundColor =[UIColor grayColor];
    
    button.backgroundColor =[UIColor whiteColor];
    //设置下面标签的位置
    _label.frame =CGRectMake(CGRectGetMinX(button.bounds),CGRectGetMaxY(button.bounds)-1, CGRectGetWidth(button.bounds),1);
    [button addSubview:_label];
    
  
    _preButton=button;
    
    
}


                               
                               
-(void)createTableView{
                                   
_tableView  = [[UITableView alloc]initWithFrame:CGRectMake(0,CGRectGetMaxY(_scrollView.bounds),self.view.bounds.size.width ,self.view.bounds.size.height-_scrollView.frame.size.height-64)];
    NSLog(@"==%@",NSStringFromCGRect(_tableView.frame));
    [self.view addSubview:_tableView];
    //设置代理
    _tableView.dataSource= self;
    _tableView.delegate =self;
    
    _refreshControl  =[[UIRefreshControl alloc]init];
    
   [_tableView addSubview:_refreshControl];
    _refreshControl.tintColor =[UIColor whiteColor];

//    _refreshControl.attributedTitle =@"松开可以刷新";
    [_refreshControl addTarget:self action:@selector(headerRefresh:) forControlEvents:UIControlEventValueChanged];
    
    //创建下拉加载更多
     _tableFooterView =[[TableFooterView alloc]initWithFrame:CGRectMake(0, 0,100, 44)];
    _tableView.tableFooterView =_tableFooterView;
    //添加手势
    
    UITapGestureRecognizer * tapGesture =[[UITapGestureRecognizer alloc]init];
    [_tableFooterView addGestureRecognizer:tapGesture];
    [tapGesture  addTarget:self action:@selector(requsetMore:)];
    
    _currentPage=1;
    [self requestForFirstPageWithUrl:[NSString stringWithFormat:FISRT_PAGE_API,_currentPage]];
    
                                   
}


-(void)requsetMore:(UITapGestureRecognizer*)sender{
    if ([_tableFooterView respondsToTouch]) {
        _tableFooterView.status = RefreshStatusLoading;
        [self requestForFirstPageWithUrl:[NSString stringWithFormat:FISRT_PAGE_API,++_currentPage]];
    }
}


-(void)headerRefresh:(UIRefreshControl*)sender{
    _currentPage=1;
    [self requestForFirstPageWithUrl:[NSString stringWithFormat:FISRT_PAGE_API,_currentPage]];


}
 
//分类滚动条请求数据
-(NSArray *)requestForButtonTitleWithUrl:(NSURL*)url{
    
    
    //通过NSData同步请求数据
    NSData * data =[NSData dataWithContentsOfURL:url];
    
    //将data转化为JSON对象
    NSDictionary * dataDict =[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
    NSArray *  resultArray = dataDict[@"result"];
    NSMutableArray * nameArray = [[NSMutableArray alloc]init];
    //遍历数组
    for (NSDictionary * dict in resultArray) {
        NSString * buttonTitle = dict[@"name"];
        [nameArray addObject:buttonTitle];
        
    }
    
    return [nameArray copy];
}

//获取首页列表
-(void)requestForFirstPageWithUrl:(NSString*)url{
    
    [self.manager GET:url parameters:nil success:^(NSURLResponse *response, NSData *data) {  //将Data转化为JSON对象
            NSDictionary * dataDict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
        NSDictionary * resultDict  = dataDict[@"result"];
        NSArray  *  carousel = resultDict[@"carousel"];
        
        //当前页为第1页时将数据清空
        if (_currentPage==1) {
            [self.dataArray removeAllObjects];
            NSMutableArray  * imageArray =[NSMutableArray array];
            
            //遍历数组
            
            for (NSDictionary * Dict in carousel) {
                
                //将字典和模型关联起来
                FirstPageFocusNewsModel * model = [[FirstPageFocusNewsModel alloc]init];
                
                [model setValuesForKeysWithDictionary:Dict];
                
                [imageArray addObject:model];
            }
            [self.dataArray addObject:imageArray];

        }
        
        NSArray * rstArray = resultDict[@"rst"];
        NSArray * dataArray =[rstArray firstObject][@"data"];
        
        // 遍历数组
        for (NSDictionary *Dict in dataArray) {
            //将字典过模型关联起来
            MainNewsModel * model =[[MainNewsModel alloc]init];
            [model setValuesForKeysWithDictionary:Dict];
            [self.dataArray addObject:model];
        }
        
        //回到主线程中刷新数据
        dispatch_async(dispatch_get_main_queue(), ^{
            [_refreshControl endRefreshing];
            [_tableView reloadData];
            //更新TableFooterview状态
            _tableFooterView.status =RefreshStatusMore;
        });

        
    } failure:^(NSURLResponse *response, NSError *error) {
        NSLog(@"%@",error.localizedDescription);
        if (_currentPage==1) {
            [_refreshControl endRefreshing];
        }
        else{
            _currentPage--;
            _tableFooterView.status =RefreshStatusError;
        }
        
    }];
    
    
    
    
    
    
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{



    return self.dataArray.count;
}


-(UITableViewCell * )tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
//复用单元格
    if (indexPath.row==0) {
        //复用单元格
        FocusCell * cell  = [tableView dequeueReusableCellWithIdentifier:@"FOCUSCELL"];
        if (!cell) {
            cell  = [[FocusCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"FOCUSCELL"];
        //此处设置cell的Frame是无效的，在代理里设置才有效
//        cell.frame=CGRectMake(0,self.navigationController.navigationBar.bounds.size.height+_scrollView.bounds.size.height , 375,FIRST_CELL_HEIGHT);
        
        
        }
        cell.imagesArray=self.dataArray[indexPath.row];
        
        NSArray * imageViewArray = cell.scrollView.subviews;
        for (UIImageView* imageView in imageViewArray) {
            //为图片视图添加手势识别器。点击查看详情
            UITapGestureRecognizer * tapGesture = [[UITapGestureRecognizer alloc]init];
            [imageView addGestureRecognizer:tapGesture];
            
            //开启用户交互
            imageView.userInteractionEnabled =YES;
            [tapGesture addTarget:self action:@selector(onTap:)];
 
        }
        
        
        return cell;
    }
    
    else{
        MainNewsCell * cell = [tableView dequeueReusableCellWithIdentifier:@"MAINCELL"];
        if (!cell) {
            static NSInteger  cellcount=0;
//            cell =[[MainNewsCell alloc]initWithFrame:CGRectMake(0,FIRST_CELL_HEIGHT+200*(indexPath.row-1),375, 200)];
    
            cell =[[MainNewsCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"MAINCELL"];
            NSLog(@"%ld",cellcount++);
            
        }
        NSLog(@"indexPath.row==%ld",indexPath.row);
        MainNewsModel * model  = self.dataArray[indexPath.row];
        cell.model =model;
        return cell;
    }

    
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if(indexPath.row==0) {
        return FIRST_CELL_HEIGHT;
    }
    else{
         static NSInteger  cellcount=0;
        NSLog(@"-------*%ld",cellcount++);
        return MAIN_NEWS_CELL_HEIGHT;
    }

}



-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
 
    NewsDetailViewController * NewDetailVC=[[NewsDetailViewController alloc]init];
   
    [self.navigationController pushViewController:NewDetailVC animated:YES];
    
    
    
}


-(void)onTap:(UITapGestureRecognizer *)sender{

    NewsDetailViewController * NewDetailVC=[[NewsDetailViewController alloc]init];
    
    [self.navigationController pushViewController:NewDetailVC animated:YES];
    



}


- (IBAction)LeftButtonClicked:(UIBarButtonItem *)sender {
    LeftTableViewController * leftVC=[[LeftTableViewController alloc]init];
    [self.navigationController pushViewController:leftVC animated:YES];
    
    
}

- (IBAction)RightButtonClicked:(UIBarButtonItem *)sender {
}
@end
