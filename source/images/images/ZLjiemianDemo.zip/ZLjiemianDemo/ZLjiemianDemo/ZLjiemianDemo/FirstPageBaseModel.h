//
//  FirstPageBaseModel.h
//  ZLjiemianDemo
//
//  Created by 千锋 on 15/12/16.
//  Copyright (c) 2015年 千锋. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FirstPageBaseModel : NSObject






@end
