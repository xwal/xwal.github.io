//
//  LeftSecondCell.h
//  ZLjiemianDemo
//
//  Created by 千锋 on 15/12/22.
//  Copyright (c) 2015年 千锋. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LeftSecondCell : UITableViewCell

@property(nonatomic,strong)UILabel * label1;
@property(nonatomic,strong)UILabel * label2;


@end
