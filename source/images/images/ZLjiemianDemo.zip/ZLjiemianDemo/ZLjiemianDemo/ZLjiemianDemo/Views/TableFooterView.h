//
//  TableFooterView.h
//  ZLjiemianDemo
//
//  Created by 千锋 on 15/12/20.
//  Copyright (c) 2015年 千锋. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef NS_ENUM(NSInteger, RefreshStatus) {
    RefreshStatusNotVisable,//不可见
    RefreshStatusLoading,  //加载中
    RefreshStatusError,   //加载错误
    RefreshStatusMore,    //加载更多
    RefreshStatusNotMore  //没有更多
};

@interface TableFooterView : UIView

@property(nonatomic,assign)RefreshStatus status;

//是否能够响应点击
-(BOOL)respondsToTouch;






@end
