//
//  LeftSecondCell.m
//  ZLjiemianDemo
//
//  Created by 千锋 on 15/12/22.
//  Copyright (c) 2015年 千锋. All rights reserved.
//

#import "LeftSecondCell.h"
#define Label1_TAG 10
#define Label2_TAG 11
@implementation LeftSecondCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}


-(instancetype)init{
    if (self =[super init] ) {
        [self createUI];
    }
 
    return self;

}




-(void)createUI{
    if (!_label1) {
        _label1 =[[UILabel alloc]init];
    }
    
    
    
    _label1.frame=CGRectMake(0, 0, self.frame.size.width/3, self.frame.size.height);
    [self.contentView addSubview:_label1];
    _label1.textAlignment  = NSTextAlignmentLeft;
    _label1.textColor =[UIColor blackColor];
    _label1.font =[UIFont systemFontOfSize:14];
    if (!_label2) {
        _label2 =[[UILabel alloc]init];
    }
    
   _label2.frame=CGRectMake(CGRectGetMaxX(_label1.frame), 0, self.frame.size.width/3*2, self.frame.size.height)
    ;
    _label2.textAlignment  = NSTextAlignmentLeft;
    _label2.textColor =[UIColor lightGrayColor];
    _label2.font =[UIFont systemFontOfSize:10];
    [self.contentView addSubview:_label2];
   
  
}










@end
