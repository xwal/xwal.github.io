//
//  FocusCell.m
//  ZLjiemianDemo
//
//  Created by 千锋 on 15/12/16.
//  Copyright (c) 2015年 千锋. All rights reserved.
//

#import "FocusCell.h"
#define PAGE_CONTROLL_WIDTH 200
#define PAGE_CONTROLL_HEIGHT 20
#import "UIImageView+WebCache.h"
#import "NewsDetailViewController.h"
#import "ViewController.h"
@interface FocusCell ()<UIScrollViewDelegate>


@end


@implementation FocusCell
{
    UIScrollView * _scrollView;//滚动视图
    UIPageControl * _pageControl;
    UILabel * _titlelabel;
    NSTimer * _timer;//焦点新闻自动换页定时器
    NSInteger _currentPage;//当前焦点新闻页数
    NSTimer * _timer1;
    NSInteger _a;
    
  }

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}



//重写初始化方法
-(instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self createUI];
    }
   
    return self;
}

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier] ) {
        [self createUI];
    }
  
    return  self;
}


-(void)createUI{
  
    _scrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0,0 ,375,250)];
    
    [self.contentView addSubview:_scrollView];
    
    //设置按页显示
    _scrollView.pagingEnabled = YES;
    
    //关闭弹簧效果
    _scrollView.bounces = NO;
    //隐藏滑动条
    _scrollView.showsHorizontalScrollIndicator=NO;
   //设置代理
    _scrollView.delegate = self;
    
    //创建定时器
    
    _timer = [NSTimer scheduledTimerWithTimeInterval:3 target:self selector:@selector(changePicture) userInfo:nil repeats:YES];
    _timer.fireDate = [NSDate distantFuture];
    
    
}


-(void)changePicture{
    if (!_currentPage) {
        _currentPage =1;
    }
   //移动 scrollview
    CGFloat  scrollviewWidth =_scrollView.bounds.size.width;
    
    CGPoint contentOffSet =_scrollView.contentOffset;
    
//     NSLog(@"定时器在工作");
    
    if(contentOffSet.x==_scrollView.frame.size.width*(_imagesArray.count)){
        
        _scrollView.contentOffset=CGPointMake(_scrollView.frame.size.width, 0);
      
        _currentPage=1;
    }
    else
    {
    
    [_scrollView setContentOffset:CGPointMake((_currentPage)*scrollviewWidth, 0) animated:YES];
    }
  
        _currentPage++;
        
    
    
    
    
    //改变_pageControll的value
    
    
}


//重写Model的Setter方法
-(void)setImagesArray:(NSArray *)imagesArray{
    //imageArray里装了很多图片Model
    _imagesArray = imagesArray;
    //设置UI
    CGFloat imageWidth = CGRectGetWidth(_scrollView.frame);
    CGFloat imageHeight  = CGRectGetHeight(_scrollView.frame);
 
    

    for (int index = 0 ; index <_imagesArray.count+2;index++){
        UIImageView * imageView = [[UIImageView alloc]initWithFrame:CGRectMake(index*imageWidth,0 , imageWidth, imageHeight)];
        [_scrollView addSubview:imageView];
        
       
        
        FirstPageFocusNewsModel * model;
        if (index==0) {
            model =_imagesArray.lastObject;
        }
        else if(index==_imagesArray.count+1) {
            model =_imagesArray.firstObject;
        }
        else{
        
            model  =_imagesArray[index -1];
        
        }
        [imageView sd_setImageWithURL:[NSURL URLWithString:model.o_image] placeholderImage:[UIImage imageNamed:@"placeholder_320_180"]];
     
        
        
        UILabel * titleLabel =[[UILabel alloc]initWithFrame:CGRectMake(10,0,imageWidth,60)];

        titleLabel.numberOfLines = 0;
        titleLabel.textColor  =[UIColor whiteColor];
        titleLabel.text =model.title;
//        titleLabel.backgroundColor = [UIColor whiteColor];
       //根据文本高度获取该高度的rect,其余不变
        CGRect  rect = [titleLabel textRectForBounds:titleLabel.bounds limitedToNumberOfLines:0];
        CGFloat height = rect.size.height;
        UIView  *  bottomView =[[UIView alloc]initWithFrame:CGRectMake(0,imageHeight-height-30,imageWidth,30+height)];
        titleLabel.frame =rect;
        
        bottomView.backgroundColor =[UIColor colorWithWhite:0 alpha:0.5];
        
        [imageView addSubview:bottomView];
        [bottomView addSubview:titleLabel];
       
    }
    
  //设置ContentSize
    _scrollView.contentSize = CGSizeMake(imageWidth*_imagesArray.count+2, imageHeight);
   
    [_scrollView setContentOffset:CGPointMake(imageWidth, 0)];
    
    
    //启动定时器
   _timer.fireDate =[NSDate distantPast];

}





//当父视图的尺寸和位置发生改变时，将回调此方法通知当前子视图去更新子视图的尺寸
//更新子视图的尺寸
-(void)layoutSubviews{
     NSLog(@"-----+++++");
    //更新UIScrollView的尺寸
    _scrollView.frame =self.frame;
    //更新子视图的尺寸
    CGFloat imageWidth = _scrollView.frame.size.width;
    CGFloat imageHeight =  _scrollView.frame.size.height;
    for (int index= 0; index<_scrollView.subviews.count; index++) {
        //取出子视图
        UIView * view =_scrollView.subviews[index];
        view.frame  = CGRectMake(index*imageWidth, 0, imageWidth, imageHeight);
        
    }
   //更新UIScorollView的contenSize
    _scrollView.contentSize = CGSizeMake(imageWidth*_scrollView.subviews.count, imageHeight);
  //创建pageControll

    [self createPageControl];
    NSLog(@"-----");
}

//创建pageControll
-(void)createPageControl{
    
    //创建pageControll
    CGSize  screenSize =[UIScreen mainScreen].bounds.size;
    _pageControl =[[UIPageControl alloc]initWithFrame:CGRectMake(self.frame.size.width-PAGE_CONTROLL_WIDTH,self.frame.size.height-PAGE_CONTROLL_HEIGHT ,PAGE_CONTROLL_WIDTH,PAGE_CONTROLL_HEIGHT)];
    [self.contentView addSubview:_pageControl];
    //设置页数
    _pageControl.numberOfPages=_imagesArray.count;
    NSLog(@"%ld",_imagesArray.count);
    //设置指定页
    _pageControl.currentPage=0;
    //设置指示器的颜色
    _pageControl.pageIndicatorTintColor=[UIColor grayColor];
    //设置指示器上当前页的颜色
    _pageControl.currentPageIndicatorTintColor =[UIColor redColor];
    //添加事件响应方法，
    [_pageControl addTarget:self action:@selector(pageChanged:) forControlEvents:UIControlEventValueChanged];
    
    
    
}


-(void)pageChanged:(UIPageControl*)sender{
    //获取当前pageControl的值
    NSInteger  currentPage =sender.currentPage;
      NSLog(@"C=======%ld",_pageControl.currentPage);
    CGPoint contentOffSet =CGPointMake(currentPage*_scrollView.frame.size.width,0);
   
    [_scrollView setContentOffset:
     contentOffSet animated:YES];
    
    
    
}


-(void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate{
    _a =0;
    _a =1;

 
}



//pageControl和ScorllView的联动 /scrollview滚动结束 暂停定时器
-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    
    
    CGPoint contentOffSet =scrollView.contentOffset;
    
    NSInteger index =contentOffSet.x/scrollView.frame.size.width+0.5;
    _pageControl.currentPage =index-1;
    _currentPage=index;
    NSLog(@"index==%ld",index);
    NSLog(@"currentPage===%ld",_pageControl.currentPage);
    if (contentOffSet.x==0) {
        _scrollView.contentOffset=CGPointMake(_imagesArray.count*scrollView.frame.size.width, 0);
        _currentPage=_imagesArray.count;
        
    }
    else if(contentOffSet.x>=_scrollView.frame.size.width*(_imagesArray.count+1)){
    
        _scrollView.contentOffset=CGPointMake(scrollView.frame.size.width, 0);
        _currentPage=1;
    
    
    }
    //暂停定时器并延迟秒启动定时器
    if (_a==1) {
        _timer.fireDate =[NSDate distantFuture];
       [self startTimer];
        _a=0;
    }
    
    
}

-(void)startTimer{
    

    NSDate * delayDate =[NSDate dateWithTimeIntervalSinceNow:3];
    
    
    _timer.fireDate=delayDate;


}





@end
