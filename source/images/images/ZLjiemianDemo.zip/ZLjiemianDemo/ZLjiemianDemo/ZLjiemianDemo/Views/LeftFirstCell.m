//
//  LeftFirstCell.m
//  ZLjiemianDemo
//
//  Created by 千锋 on 15/12/21.
//  Copyright (c) 2015年 千锋. All rights reserved.
//

#import "LeftFirstCell.h"
#define DIVIDE_LABEL_WIDTH 0.25
@interface LeftFirstCell ()

//@property(nonatomic,strong)UIImageView * imageView;


@end





@implementation LeftFirstCell


- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}






-(instancetype)init{
   
    if (self =[super init] ) {
        [self createUI];
    }
 
    return self;
}



-(void)createUI{
    
    //设置每一小格的尺寸
    CGFloat  ImageViewWidth =self.frame.size.width/3-DIVIDE_LABEL_WIDTH;
    CGFloat  ImageViewHeight =self.frame.size.height;
    for (int index=0; index<3; index++) {
        UIImageView * imageView =[[UIImageView alloc]initWithFrame:CGRectMake(ImageViewWidth*index, 0, ImageViewWidth, ImageViewHeight)];
        //标题视图
        UIImageView * smallimageView =[[UIImageView alloc]initWithFrame:CGRectMake(0,5,ImageViewWidth/2-10, ImageViewHeight-5)];
        UILabel * titileLabel  =[[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(smallimageView.frame), 0, ImageViewWidth/2, ImageViewHeight)];
        
        UILabel * divideLabel = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(imageView.frame),0,0.25, ImageViewHeight)];
        //文本居中对齐
        titileLabel.textAlignment =NSTextAlignmentCenter;
        //文本颜色
        titileLabel.textColor =[UIColor blackColor];
        //文本字体
        titileLabel.font =[UIFont systemFontOfSize:14];
        [imageView addSubview:smallimageView];
        [imageView addSubview:titileLabel];
        
        [self.contentView addSubview:imageView];
        if (index<2){
        [self.contentView addSubview:divideLabel];
        }
        
    }
   


}

-(void)layoutSubviews{
 
    







}






@end
