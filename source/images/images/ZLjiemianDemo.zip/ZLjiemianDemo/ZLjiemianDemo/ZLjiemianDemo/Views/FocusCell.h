//
//  FocusCell.h
//  ZLjiemianDemo
//
//  Created by 千锋 on 15/12/16.
//  Copyright (c) 2015年 千锋. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FirstPageFocusNewsModel.h"
@interface FocusCell : UITableViewCell

//图片数组
@property(nonatomic,strong)NSArray * imagesArray;
@property(nonatomic,strong)UIScrollView * scrollView;

@end
