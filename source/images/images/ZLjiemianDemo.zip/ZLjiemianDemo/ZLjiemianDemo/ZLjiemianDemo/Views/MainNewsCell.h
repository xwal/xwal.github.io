//
//  MainNewsCell.h
//  ZLjiemianDemo
//
//  Created by 千锋 on 15/12/17.
//  Copyright (c) 2015年 千锋. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MainNewsModel.h"

@interface MainNewsCell : UITableViewCell

@property(nonatomic, strong)MainNewsModel * model;


@end


