//
//  MainNewsCell.m
//  ZLjiemianDemo
//
//  Created by 千锋 on 15/12/17.
//  Copyright (c) 2015年 千锋. All rights reserved.
//

#import "MainNewsCell.h"
#import "UIImageView+WebCache.h"
@implementation MainNewsCell
{
    UIImageView *_imageView;
    UILabel * _titleLabel;
 



}
- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}


-(void)layoutSubviews{
    //设置UI
    if (!_imageView) {
       
        static NSInteger  cellcount=0;
        NSLog(@"===----==%ld",cellcount++);
    _imageView = [[UIImageView alloc]init];
     
        [self.contentView addSubview:_imageView];
       
    }
    if (!_titleLabel) {
        //设置标题
        _titleLabel =[[UILabel alloc]init];
  
        
        _titleLabel.textColor= [UIColor grayColor];
        _titleLabel.numberOfLines =0;
            _titleLabel.font =[UIFont systemFontOfSize:20];

        _titleLabel.adjustsFontSizeToFitWidth =YES;
        [self.contentView addSubview:_titleLabel];
         NSLog(@"*%@",_titleLabel.text);
    }
   //视图布局
     static NSInteger  cellcount=0;
    NSLog(@"======%ld",cellcount++);
    _imageView.frame =CGRectMake(0, 10, self.frame.size.width,self.frame.size.height/3*2);
    _titleLabel.frame =CGRectMake(0,CGRectGetMaxY(_imageView.frame),CGRectGetWidth(_imageView.frame),30);
   //设置UI的值
      [_imageView sd_setImageWithURL:[NSURL URLWithString:_model.o_image] placeholderImage:[UIImage imageNamed:@"channel_default@3x"]];
    
     _titleLabel.text =_model.title;

}




@end

