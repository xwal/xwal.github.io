//
//  TableFooterView.m
//  ZLjiemianDemo
//
//  Created by 千锋 on 15/12/20.
//  Copyright (c) 2015年 千锋. All rights reserved.
//

#import "TableFooterView.h"
#import "Masonry.h"
@implementation TableFooterView
{
    UIActivityIndicatorView * _indicatorView;
    UILabel *  _textLabel;
    
}


- (instancetype)init
{
    self = [super init];
    if (self) {
        [self createView];
    }
    return self;
}

-(instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self createView];
    }
    return self;
 
}




-(void)createView{
    _textLabel =[[UILabel alloc]initWithFrame:self.bounds];
    [self addSubview:_textLabel];
    _textLabel.textAlignment =NSTextAlignmentCenter;
    _textLabel.font =[UIFont systemFontOfSize:14];
    
    //关闭停靠模式
    _textLabel.translatesAutoresizingMaskIntoConstraints =NO;
    [_textLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        //全等
        make.edges.equalTo(self);
    }];
    //创建灰色活动指示器
    _indicatorView =[[UIActivityIndicatorView alloc]init];
    [self addSubview:_indicatorView];
    _indicatorView.backgroundColor=[UIColor orangeColor];
    _indicatorView.translatesAutoresizingMaskIntoConstraints =NO;
    [_indicatorView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.center.equalTo(_textLabel);
    }];
//    _indicatorView.hidden =YES;

}


//是否能够响应点击
-(BOOL)respondsToTouch{
  //判断当前状态
    BOOL isTouch =self.status == RefreshStatusMore||self.status==RefreshStatusError;
    
    return isTouch;
}


// 重写Status的Setter方法
-(void)setStatus:(RefreshStatus)status{
    _status = status;
   
    NSArray * textArray =@[@"",@"加载中",@"加载错误",@"加载更多",@"没有更多"];
    _textLabel.text =textArray[_status];
    if (status==RefreshStatusLoading) {
        _indicatorView.hidden=NO;
        [_indicatorView startAnimating];
    }
    else{
        _indicatorView.hidden = YES;
        [_indicatorView stopAnimating];
    }
    
}




@end
