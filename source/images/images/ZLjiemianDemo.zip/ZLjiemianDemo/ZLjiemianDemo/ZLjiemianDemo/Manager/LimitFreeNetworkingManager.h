//
//  LimitFreeNetworkingManager.h
//  LimitFreeDemo
//
//  Created by Chaosky on 15/12/14.
//  Copyright © 2015年 1000phone. All rights reserved.
//

#import <Foundation/Foundation.h>

// 请求成功的Block
typedef void(^RequestSuccess)(NSURLResponse * response, NSData * data);
// 请求失败的block
typedef void(^RequestFailure)(NSURLResponse * response, NSError * error);

@interface LimitFreeNetworkingManager : NSObject

// 创建对象的类方法
+ (instancetype)manager;

// GET请求数据
- (void)GET:(NSString *) url parameters:(NSDictionary *)parameters
    success:(RequestSuccess)success
    failure:(RequestFailure)failure;

@end
