//
//  FirstPageBaseModel.m
//  ZLjiemianDemo
//
//  Created by 千锋 on 15/12/16.
//  Copyright (c) 2015年 千锋. All rights reserved.
//

#import "FirstPageBaseModel.h"

@implementation FirstPageBaseModel
//解决外部访问不存在的Key
-(void)setValue:(id)value forUndefinedKey:(NSString *)key{


}


-(id)valueForUndefinedKey:(NSString *)key{



    return nil;
}





@end
