//
//  NewsDetailViewController.m
//  ZLjiemianDemo
//
//  Created by 千锋 on 15/12/27.
//  Copyright (c) 2015年 千锋. All rights reserved.
//

#import "NewsDetailViewController.h"

@interface NewsDetailViewController ()

@end

@implementation NewsDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
//    
//    self.navigationItem.leftBarButtonItem =;
    
    
    
    
    
    


}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
