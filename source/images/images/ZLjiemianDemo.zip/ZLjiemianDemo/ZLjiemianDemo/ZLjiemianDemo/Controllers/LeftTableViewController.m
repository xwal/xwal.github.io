//
//  LeftTableViewController.m
//  ZLjiemianDemo
//
//  Created by 千锋 on 15/12/21.
//  Copyright (c) 2015年 千锋. All rights reserved.
//

#import "LeftTableViewController.h"
#import "LeftViewModel.h"
#import "LeftFirstCell.h"
#import "LeftSecondCell.h"
#import "LimitFreeNetworkingManager.h"
@interface LeftTableViewController ()
@property(nonatomic,strong)LimitFreeNetworkingManager*manager;
@end
//tableViewController自带了一个tableview
@implementation LeftTableViewController
{

    NSMutableArray * _dataArray;
    
}

//懒加载
-(LimitFreeNetworkingManager*)manager{
    if (!_manager) {
        _manager =[LimitFreeNetworkingManager manager];
    }
   
    return  _manager;

}

//栏加载，实例变量不能访问 初始化数组
-(NSMutableArray *)dataArray{
    if (!_dataArray) {
        _dataArray=[[NSMutableArray alloc]init];
    }
    
    return _dataArray;
}



- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    self.tableView.sectionFooterHeight=0;
    
    self.tableView = [[UITableView alloc]initWithFrame:self.tableView.bounds style:UITableViewStyleGrouped];
    self.tableView.rowHeight  =55;
    [self requestLeftTabelViewWithURL:LEFT_MENU_API];

  
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}




   

  


-(void)requestLeftTabelViewWithURL:(NSString *)url{
    
      [self.manager GET:url parameters:nil success:^(NSURLResponse *response, NSData *data) {
          NSDictionary * responseDict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
          NSArray *  channelArray = [responseDict[@"result"]  objectForKey:@"channel"];
          _dataArray = [NSMutableArray array];
          NSDictionary * cooperationDict =[responseDict[@"result"] objectForKey: @"cooperation"];
          NSArray * dataArr =[cooperationDict objectForKey:@"data"];
          NSMutableArray * firstSectionArray =[NSMutableArray array];
          //遍历数组
          for (int index=0; index<channelArray.count; index++) {
              
                  
              
              NSDictionary * valueDict =channelArray[index];
              NSArray * rowsArray =valueDict[@"rows"];
              if (index<4) {
                  
              LeftViewModel * model =[[LeftViewModel alloc]init];
              [model setValuesForKeysWithDictionary:[rowsArray firstObject]];
              [firstSectionArray addObject:model];
              }
              else{
                  NSMutableArray * modelsArray=[[NSMutableArray alloc]init];
                  for (NSDictionary*valueDict in rowsArray ) {
                      LeftViewModel *model =[[LeftViewModel alloc]init];
                      [model setValuesForKeysWithDictionary:valueDict];
                      [modelsArray addObject:model];
                      
                  }
                  
                  [firstSectionArray addObject:modelsArray];
              
              }
          
          }
          [self.dataArray addObject:firstSectionArray];
          NSMutableArray * SecondSectionArray =[NSMutableArray array];
          
          //遍历数组
          
          for (NSDictionary *Dict in dataArr) {
              LeftViewModel * model =[[LeftViewModel alloc]init];
              [model setValuesForKeysWithDictionary:Dict];
              [SecondSectionArray addObject:model];
          }
          [self.dataArray addObject:SecondSectionArray];
          
          //回到主队列刷新数据
           dispatch_async(dispatch_get_main_queue(), ^{
               [self.tableView reloadData];
           });
          
      } failure:^(NSURLResponse *response, NSError *error) {
          NSLog(@"%@",error.localizedDescription);
      }];
    
    


}






#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
//NSLog(@"``````%ld",self.dataArray.count);
    return self.dataArray.count;
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSArray * sectionArr =self.dataArray[section];
    return sectionArr.count;
}


-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
       if (indexPath.section==0) {
           NSArray * firstSectionArr =_dataArray[indexPath.section];

        if (indexPath.row<4) {
            
        UITableViewCell  *  cell =[tableView dequeueReusableCellWithIdentifier:@"CELL"];
            
            if (!cell) {
                
            
                cell  =[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"CELL"];
            }
         ;
            LeftViewModel * model  = firstSectionArr[indexPath.row];
            

            cell.imageView.image = [UIImage imageNamed:model.icon];
                    NSLog(@"0000000%@",model.icon);

            cell.textLabel.text = model.title;
            cell.detailTextLabel.text= model.slogan;
            
            return cell;
        }
        else{
            LeftFirstCell * cell  =[tableView dequeueReusableCellWithIdentifier:@"CELL"];
            
            if (!cell) {
                cell =[[LeftFirstCell alloc]init];
            }
            
            
           //取出数据
            NSArray * modelsArray  =firstSectionArr[indexPath.row];
            NSArray * subviewsArray =cell.contentView.subviews;
            for (int index = 0; index<subviewsArray.count; index++) {
                if (index%2==0) {
                UIImageView   * imageView =   subviewsArray[index];//0,2,4
                    
                    UIImageView * firstsmallImageView=imageView.subviews.firstObject;
                    LeftViewModel * model =[modelsArray objectAtIndex:index/2];

                    [firstsmallImageView sd_setImageWithURL:[NSURL URLWithString:model.icon] placeholderImage:[UIImage imageNamed:model.icon]];
                    
                    UILabel * titleLabel =imageView.subviews.lastObject;
                    titleLabel.text =model.title;
                  }
            }
                    return cell;
        }
    
    }
    else{
        
        LeftSecondCell * cell = [tableView dequeueReusableCellWithIdentifier:@"CELL"];
        if (!cell) {
            
            cell = [[LeftSecondCell alloc]init];
        }
        //取出数据
        NSArray * sectionArr =_dataArray[indexPath.section];
        
        LeftViewModel * model =sectionArr[indexPath.row];
        cell.label1.text =model.title;
        cell.label2.text =model.slogan;
       
        return cell;
    }
    


  
   
}


//自定义组头
-(UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    
    if (section==0) {
        
        UIView * sectionHeaderView =[[UIView alloc]initWithFrame:CGRectMake(0, 0, 370, 50)];
        
        //组头标题
        UILabel * titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(0,0,sectionHeaderView.frame.size.width/4,sectionHeaderView.frame.size.height)];
        titleLabel.center =sectionHeaderView.center;
        titleLabel.textColor =[UIColor blackColor];
        titleLabel.font = [UIFont systemFontOfSize:13];
        titleLabel.textAlignment =NSTextAlignmentCenter;
        
        
        titleLabel.text = @"战略合作";
        [sectionHeaderView addSubview:titleLabel];
        //设置组头左视图
        UIImageView * leftView =[[UIImageView alloc]initWithFrame:CGRectMake(CGRectGetMinX(titleLabel.frame)-36,CGRectGetMidY(titleLabel.frame),36,5)];
        [sectionHeaderView addSubview:leftView];
        leftView.image =[UIImage imageNamed:@"menu_identify_left"];
        //设置组头右视图
        UIImageView * rightView =[[UIImageView alloc]initWithFrame:CGRectMake(CGRectGetMaxX(titleLabel.frame),CGRectGetMidY(titleLabel.frame),36,5)];
        rightView.image =[UIImage imageNamed:@"menu_identify_right"];
        [sectionHeaderView addSubview:rightView];
//
        sectionHeaderView.backgroundColor = [UIColor redColor];
//
        return sectionHeaderView;
    }
    else{
        
        UIView * sectionHeaderView =[[UIView alloc]initWithFrame:CGRectMake(0, 0, 370, 10)];
        
        
        //组头标题
        UILabel * titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(0,0,sectionHeaderView.frame.size.width/2,sectionHeaderView.frame.size.height)];
        titleLabel.center =sectionHeaderView.center;
        titleLabel.textColor =[UIColor blackColor];
        titleLabel.font = [UIFont systemFontOfSize:13];
        titleLabel.textAlignment =NSTextAlignmentCenter;
        
        
        titleLabel.text = @"为独立是思考人群服务";
        [sectionHeaderView addSubview:titleLabel];
        //设置组头左视图
        UIImageView * leftView =[[UIImageView alloc]initWithFrame:CGRectMake(CGRectGetMinX(titleLabel.frame)-36,CGRectGetMidY(titleLabel.frame),36,5)];
        [sectionHeaderView addSubview:leftView];
        leftView.image =[UIImage imageNamed:@"menu_identify_left"];
        //设置组头右视图
        UIImageView * rightView =[[UIImageView alloc]initWithFrame:CGRectMake(CGRectGetMaxX(titleLabel.frame),CGRectGetMidY(titleLabel.frame),36,5)];
        rightView.image =[UIImage imageNamed:@"menu_identify_right"];
        [sectionHeaderView addSubview:rightView];
        

        return  sectionHeaderView;
    }
    
   }

////自定义组尾
//-(UIView*)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
//
//    UIView * sectionFooterView =[[UIView alloc]initWithFrame:CGRectMake(0, 0, 370, 10)];
//    
//    //组头标题
//    UILabel * titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(0,0,sectionFooterView.frame.size.width/2,sectionFooterView.frame.size.height)];
//    titleLabel.center =sectionFooterView.center;
//    titleLabel.textColor =[UIColor blackColor];
//    titleLabel.font = [UIFont systemFontOfSize:13];
//    titleLabel.textAlignment =NSTextAlignmentCenter;
//    
//    
//    titleLabel.text = @"为独立是思考人群服务";
//    [sectionFooterView addSubview:titleLabel];
//    //设置组头左视图
//    UIImageView * leftView =[[UIImageView alloc]initWithFrame:CGRectMake(CGRectGetMinX(titleLabel.frame)-36,CGRectGetMidY(titleLabel.frame),36,5)];
//       [sectionFooterView addSubview:leftView];
//    leftView.image =[UIImage imageNamed:@"menu_identify_left"];
//    //设置组头右视图
//    UIImageView * rightView =[[UIImageView alloc]initWithFrame:CGRectMake(CGRectGetMaxX(titleLabel.frame),CGRectGetMidY(titleLabel.frame),36,5)];
//    rightView.image =[UIImage imageNamed:@"menu_identify_right"];
//    [sectionFooterView addSubview:rightView];
//    
//    
//    return sectionFooterView;
//
//
//
//}




@end
