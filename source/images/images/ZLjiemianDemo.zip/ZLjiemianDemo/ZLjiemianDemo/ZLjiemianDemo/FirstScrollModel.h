//
//  FirstScrollModel.h
//  ZLjiemianDemo
//
//  Created by 千锋 on 15/12/13.
//  Copyright (c) 2015年 千锋. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FirstScrollModel : NSObject




@end
